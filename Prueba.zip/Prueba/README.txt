1) Se utlizo la pagina https://fronty.com/dashboard para convertir la imagen en codigo HTML y CSS

2) para el paginado, se utlizo el ejemplo de la pagina https://codepen.io/marcomarasco/pen/aGojVb

3) Para llenar el combo se esta consumiendo la api https://api.myjson.com/bins/7xq2x

4) para utilizar la pagina podria publicarse en el iis siguiendo los pasos detallados en la siguiente pagina: https://support.microsoft.com/es-ar/help/323972/how-to-set-up-your-first-iis-web-site

y para acceder, colocar la ip del servidor mas el puerto

5) El diseño y creacion del modal de inicio de sesion lo obtuve de las siguientes paginas: 
	
	a- https://mdbootstrap.com/docs/jquery/modals/events/
	
	b - 
	
	y utlice las archivos css mdb.css descargados https://mdbootstrap.com/docs/jquery/modals/events/#docsTabsAPI
	
Nota: la pagina original convertida desde la imagen es: https://fronty.com:8181/app/page/f94e779e-1d9c-4a40-a997-6958d5346003/index.html
